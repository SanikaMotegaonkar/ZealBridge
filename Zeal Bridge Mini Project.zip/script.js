document.getElementById("loginBtn").addEventListener("click", () => {
  alert("Login feature coming soon!");
});

document.getElementById("registerBtn").addEventListener("click", () => {
  alert("Register feature coming soon!");
});